const manipulate = require("./manipulate");

module.exports = {
    manipulate: manipulate
}