const eduData = require("./education");
const hobData = require("./hobbies");
const classData = require("./classes");

module.exports = {
    education: eduData, 
    hobbies: hobData, 
    classes: classData
};