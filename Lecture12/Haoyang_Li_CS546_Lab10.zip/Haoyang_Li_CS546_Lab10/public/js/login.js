// (function ($) {

    
//         var myForm = $("#login-form");

//         myForm.submit(function (event) {
//             event.preventDefault();

//             var username = $("#username").val();
//             var password = $("#password").val();
            
//             if (!username) {
//                 $("#error-username").append("<div style='color:#0000FF'>Please provide username</div>");
//                 event.preventDefault();
//             }

//             if (!password) {
//                 $("#error-password").append("<div style='color:#0000FF'>Please provide password</div>");
//                 event.preventDefault();
//             }

//             if (username) {
//                 $("#error-username").remove();
//                 event.preventDefault();
//             }

//             if (password) {
//                 $("#error-password").remove();
//                 event.preventDefault();
//             }
            

//     })

// })(jQuery, window.localStorage);