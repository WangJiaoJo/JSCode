module.exports = {
    private: require("./private")
};